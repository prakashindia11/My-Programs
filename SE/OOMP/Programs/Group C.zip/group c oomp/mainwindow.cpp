#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <pthread.h>
#include<iostream>
#include<unistd.h>
#include <sched.h>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

int a[3][3],b[3][3],c[3][3];
pthread_t t1,t2,t3;
cpu_set_t cpu1, cpu2, cpu3;

void* multiply(void* r)
{
    int j,k;
    int r1 = *((int *)r);
    int x=0;
    for(j =0;j<3;j++)
        {
            x=0;
            for(k=0;k<3;k++)
            {
                x += (a[r1][k])*(b[k][j]);
            }

            c[r1][j]=x;
        }
}



void MainWindow::on_pushButton_clicked()
{

    int tr1,tr2,tr3,temp;

    a[0][0]=this->ui->lineEdit->text().toInt();
    a[0][1]=this->ui->lineEdit_2->text().toInt();
    a[0][2]=this->ui->lineEdit_3->text().toInt();
    a[1][0]=this->ui->lineEdit_4->text().toInt();
    a[1][1]=this->ui->lineEdit_5->text().toInt();
    a[1][2]=this->ui->lineEdit_6->text().toInt();
    a[2][0]=this->ui->lineEdit_7->text().toInt();
    a[2][1]=this->ui->lineEdit_8->text().toInt();
    a[2][2]=this->ui->lineEdit_9->text().toInt();

    b[0][0]=this->ui->lineEdit_10->text().toInt();
    b[0][1]=this->ui->lineEdit_11->text().toInt();
    b[0][2]=this->ui->lineEdit_12->text().toInt();
    b[1][0]=this->ui->lineEdit_13->text().toInt();
    b[1][1]=this->ui->lineEdit_14->text().toInt();
    b[1][2]=this->ui->lineEdit_15->text().toInt();
    b[2][0]=this->ui->lineEdit_16->text().toInt();
    b[2][1]=this->ui->lineEdit_17->text().toInt();
    b[2][2]=this->ui->lineEdit_18->text().toInt();



    try
    {

        tr1=pthread_create(&t1,NULL,multiply,(void*)0);
        CPU_ZERO(&cpu1);
        CPU_SET(1, &cpu1);
        temp = pthread_setaffinity_np(t1, sizeof(cpu_set_t), &cpu1);


        tr2=pthread_create(&t2,NULL,multiply,(void*)1);
        CPU_ZERO(&cpu2);
        CPU_SET(2, &cpu2);
        temp = pthread_setaffinity_np(t2, sizeof(cpu_set_t), &cpu2);

        tr3=pthread_create(&t3,NULL,multiply,(void*)2);
        CPU_ZERO(&cpu3);
        CPU_SET(1, &cpu3);
        temp = pthread_setaffinity_np(t3, sizeof(cpu_set_t), &cpu3);

        pthread_join(t1,NULL);
        pthread_join(t2,NULL);
        pthread_join(t3,NULL);

        this->ui->c00->setText(QString::number(c[0][0]));
        this->ui->c01->setText(QString::number(c[0][1]));
        this->ui->c02->setText(QString::number(c[0][2]));
        this->ui->c10->setText(QString::number(c[1][0]));
        this->ui->c11->setText(QString::number(c[1][1]));
        this->ui->c12->setText(QString::number(c[1][2]));
        this->ui->c20->setText(QString::number(c[2][0]));
        this->ui->c21->setText(QString::number(c[2][1]));
        this->ui->c22->setText(QString::number(c[2][2]));
    }
    catch(char const *s)
    {
        cout<<s;
    }


}

void MainWindow::on_pushButton_2_clicked()
{
    long c = sysconf( _SC_NPROCESSORS_ONLN );
    this->ui->corecount->setText(QString::number(c));
}
