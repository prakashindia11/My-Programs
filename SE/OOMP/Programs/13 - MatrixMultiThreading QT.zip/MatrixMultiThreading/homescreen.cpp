
#include "homescreen.h"
#include "ui_homescreen.h"
#include <iostream>
#include <unistd.h>
#include <pthread.h>
#include <sched.h>
#include <qmessagebox.h>


HomeScreen::HomeScreen(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HomeScreen)
{
    ui->setupUi(this);
}

HomeScreen::~HomeScreen()
{
    delete ui;
}


//Matrices
float fM1[3][3],fM2[3][3],fM3[3][3];

//Threads
pthread_t thMultOne,thMultSecond,thMultThird;

//Cpu Core Selectors
cpu_set_t csCpu1,csCpu2,csCpu3;


//Matrix  Multiplication Functions

void* MultiplyRow1(void *r)
{
    int i,j;
    float x =0;

    for(i=0;i<3;i++)
    {
        x = 0;
        for(j=0;j<3;j++)
        {
            x += fM1[0][j] * fM2[j][i];
        }
        fM3[0][i] = x;
    }
}

void* MultiplyRow2(void *r)
{
    int i,j;
    float x =0;

    for(i=0;i<3;i++)
    {
        x = 0;
        for(j=0;j<3;j++)
        {
            x += fM1[1][j] * fM2[j][i];
        }
        fM3[1][i] = x;
    }
}

void* MultiplyRow3(void *r)
{
    int i,j;
    float x =0;

    for(i=0;i<3;i++)
    {
        x = 0;
        for(j=0;j<3;j++)
        {
            x += fM1[2][j] * fM2[j][i];
        }
        fM3[2][i] = x;
    }
}


// Listener Events

void HomeScreen::on_bShowTotalCores_clicked()
{
    long lnTotalCores = sysconf(_SC_NPROCESSORS_ONLN);
    ui->tfTotalCores->setText(QString::number(lnTotalCores));
}


void HomeScreen::on_bMultiplMatrices_clicked()
{

    //Getting Values Fro UI
    fM1[0][0] = ui->tfM111->text().toFloat();
    fM1[0][1] = ui->tfM112->text().toFloat();
    fM1[0][2] = ui->tfM113->text().toFloat();
    fM1[1][0] = ui->tfM121->text().toFloat();
    fM1[1][1] = ui->tfM122->text().toFloat();
    fM1[1][2] = ui->tfM123->text().toFloat();
    fM1[2][0] = ui->tfM131->text().toFloat();
    fM1[2][1] = ui->tfM132->text().toFloat();
    fM1[2][2] = ui->tfM133->text().toFloat();

    fM2[0][0] = ui->tfM211->text().toFloat();
    fM2[0][1] = ui->tfM212->text().toFloat();
    fM2[0][2] = ui->tfM213->text().toFloat();
    fM2[1][0] = ui->tfM221->text().toFloat();
    fM2[1][1] = ui->tfM222->text().toFloat();
    fM2[1][2] = ui->tfM223->text().toFloat();
    fM2[2][0] = ui->tfM231->text().toFloat();
    fM2[2][1] = ui->tfM232->text().toFloat();
    fM2[2][2] = ui->tfM233->text().toFloat();

    //Calling Functions using threads assigned to multiple cores at a time
    int iThread1,iThread2,iThread3,iTemp;
    try
    {
        iThread1 = pthread_create(&thMultOne,NULL,MultiplyRow1,(void*)0);
        CPU_ZERO(&csCpu1);
        CPU_SET(ui->tfCoreChoice1->text().toInt(), &csCpu1);
        iTemp = pthread_setaffinity_np(thMultOne, sizeof(cpu_set_t),&csCpu1);


        iThread2 = pthread_create(&thMultSecond,NULL,MultiplyRow2,(void *)1);
        CPU_ZERO(&csCpu2);
        CPU_SET(ui->tfCoreChoice2->text().toInt(),&csCpu2);
        iTemp = pthread_setaffinity_np(thMultSecond,sizeof(cpu_set_t),&csCpu2);

        iThread3 = pthread_create(&thMultThird,NULL,MultiplyRow3,(void*)2);
        CPU_ZERO(&csCpu3);
        CPU_SET(ui->tfCoreChoice3->text().toInt(),&csCpu3);
        iTemp = pthread_setaffinity_np(thMultThird,sizeof(cpu_set_t), &csCpu3);


        pthread_join(thMultOne,NULL);
        pthread_join(thMultSecond,NULL);
        pthread_join(thMultThird,NULL);


        ui->tfM311->setText(QString::number(fM3[0][0]));
        ui->tfM312->setText(QString::number(fM3[0][1]));
        ui->tfM313->setText(QString::number(fM3[0][2]));
        ui->tfM321->setText(QString::number(fM3[1][0]));
        ui->tfM322->setText(QString::number(fM3[1][1]));
        ui->tfM323->setText(QString::number(fM3[1][2]));
        ui->tfM331->setText(QString::number(fM3[2][0]));
        ui->tfM332->setText(QString::number(fM3[2][1]));
        ui->tfM333->setText(QString::number(fM3[2][2]));

    }
    catch(...)
    {
        QMessageBox qmError;
        qmError.setText("Error");
        qmError.exec();
    }

}
