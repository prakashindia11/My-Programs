#ifndef MODIFYDIALOG_H
#define MODIFYDIALOG_H

#include <QDialog>

namespace Ui {
class modifydialog;
}

class modifydialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit modifydialog(QWidget *parent = 0);
    ~modifydialog();
    static QString path,filename;
    
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::modifydialog *ui;
};

#endif // MODIFYDIALOG_H
