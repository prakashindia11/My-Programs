#ifndef PERSONRECORD_H
#define PERSONRECORD_H

#include <QMainWindow>
#include "PersonInfo.cpp"

namespace Ui {
class PersonRecord;
}

class PersonRecord : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit PersonRecord(QWidget *parent = 0);
    ~PersonRecord();
    void appendData(Person *pointer,QString &str);
    
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

public:
    Ui::PersonRecord *ui;
};

#endif // PERSONRECORD_H
