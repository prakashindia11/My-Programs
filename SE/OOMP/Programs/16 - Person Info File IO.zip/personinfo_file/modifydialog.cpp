#include "modifydialog.h"
#include "ui_modifydialog.h"
#include "personrecord.h"
#include <QMessageBox>

modifydialog::modifydialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifydialog)
{
    ui->setupUi(this);
}

modifydialog::~modifydialog()
{
    delete ui;
}


void modifydialog::on_pushButton_2_clicked()
{
    QFile personfile(modifydialog::path+"/"+modifydialog::filename);

    if(!personfile.open(QIODevice::ReadWrite | QIODevice::Text)) {
        QMessageBox::warning(this,"Error","The file I/O error\nPlease try again");
        return;
    }

    QTextStream personstream(&personfile);
    QString file_info = personstream.readAll();


    try{
    int index = file_info.indexOf(ui->lineEdit_1->text());
    if(index == -1){
        throw -1;
    }
    file_info.replace(index,ui->lineEdit_1->text().length(),ui->lineEdit_2->text());


    personfile.resize(0);
    personstream << file_info;
    personstream.flush();
    personfile.close();

    QMessageBox::information(this,"Successfull","Record successfully modified\nThank You!");
    }

    catch(int){
        QMessageBox::warning(this,"Not found","Sorry,Your entry not found");
    }

    accept();
}


QString modifydialog::path;
QString modifydialog::filename;
