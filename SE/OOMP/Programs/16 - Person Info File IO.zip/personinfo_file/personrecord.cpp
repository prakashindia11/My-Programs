#include "personrecord.h"
#include "ui_personrecord.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include "modifydialog.h"


PersonRecord::PersonRecord(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PersonRecord)
{
    ui->setupUi(this);

}

PersonRecord::~PersonRecord()
{
    delete ui;
}

int Person::no_of_person = 0;
Person *personpointer;


void PersonRecord::on_pushButton_clicked()
{
    if(ui->lineEdit_1->text().length() == 0){
        QMessageBox::warning(this,"Error","Please enter valid details");
    }
    else{
        try{
    personpointer = new Person();
    personpointer->name = ui->lineEdit_1->text();
    personpointer->address = ui->lineEdit_2->text();
    personpointer->date_of_birth = ui->lineEdit_3->text();
    personpointer->contact_no = ui->lineEdit_4->text();

    ui->lineEdit_1->setText("");
    ui->lineEdit_2->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");

    QFile personfile(ui->lineEdit_5->text()+"/"+ui->lineEdit_6->text());

    if(!personfile.open(QIODevice::ReadWrite | QIODevice::Text)) {
        throw -1;
    }

    QTextStream personstream(&personfile);
    QString info = personstream.readAll();
    if(info.size() == 0){
        personstream.setFieldWidth(143);
         personstream.setFieldAlignment(QTextStream::AlignCenter);
         personstream.setPadChar('*');
         personstream << "PERSON RECORD";
         personstream.reset();
         personstream << "\n\n\n";
    }
    info.clear();
    appendData(personpointer,info);
    personstream << info;

    personstream.flush();
    personfile.close();

    QMessageBox::information(this,"Successfull","Your entry successfully added \nThank You!");

    }
        catch(int){
            QMessageBox::warning(this,"Error","The file I/O error\nPlease try again");

        }
        catch(...){
            QMessageBox::warning(this,"Error","Sorry some error occured\nPlease try again");
        }
    }
}

void PersonRecord::appendData(Person *pointer,QString &str ){
    str.append("Name:"+pointer->name+"\n"+"Contact Address:"+pointer->address+"\n"+"Date of birth:"+pointer->date_of_birth+"\n"+"Contact No:"+pointer->contact_no+"*\n\n");

}

void PersonRecord::on_pushButton_2_clicked()
{
    modifydialog::path = ui->lineEdit_5->text();
    modifydialog::filename = ui->lineEdit_6->text();
    modifydialog dialog;
    dialog.setWindowTitle("Find");
    dialog.setModal(true);
    dialog.exec();
}

void PersonRecord::on_pushButton_3_clicked()
{
    if(ui->lineEdit_1->text().length() == 0){
        QMessageBox::warning(this,"Error","Please enter valid name");
    }
    else{
    QFile personfile(ui->lineEdit_5->text()+"/"+ui->lineEdit_6->text());
    if(!personfile.open(QIODevice::ReadWrite | QIODevice::Text)) {
        QMessageBox::warning(this,"Error","The file I/O error\nPlease try again");
        return;
    }

    QTextStream personstream(&personfile);
    QString info = personstream.readAll();

    try{
    int index = info.indexOf(ui->lineEdit_1->text());
    if(index == -1){
        throw -1;
    }
    int last_index = info.indexOf("*",index);

    info.remove(index-5,last_index-index+5+sizeof("\n\n"));

    personfile.resize(0);
    personstream << info;

    personstream.flush();
    personfile.close();
    ui->lineEdit_1->setText("");

    QMessageBox::information(this,"Succesfull","The record successfully removed");
    }
    catch(int){
        QMessageBox::warning(this,"Not found","Your record not found");
    }
    }

}
