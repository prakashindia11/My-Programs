#include <QtCore>

class Person{
public:
    QString name,address,date_of_birth,contact_no;
    static int no_of_person;

    Person(){
        name = address = "Invalid data";
        no_of_person++;
    }
};


