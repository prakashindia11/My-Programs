#include "homescreen.h"
#include "ui_homescreen.h"
#include "string.h"
#include "string"
#include "iostream"
#include "spawn.h"

HomeScreen::HomeScreen(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HomeScreen)
{
    ui->setupUi(this);
}

HomeScreen::~HomeScreen()
{
    delete ui;
}

void HomeScreen::on_bCreateFolder_clicked()
{
    //Required Variables
    int iPIDMkdir,iStatusMkdir;
    char chCommand[] = "mkdir";
    char chFolderName[20];

    std::string sFolderName;
    sFolderName = ui->tfFolderName->text().toStdString();

    int iLength= this->ui->tfFolderName->text().toStdString().length();
    this->ui->tfFolderName->text().toStdString().copy(chFolderName,l,0);
    chFolderName[iLength]='\0';

    char* chCommandWithAttr[] = {chCommand,chFolderName,0};

    iStatusMkdir = posix_spawnp(&iPIDMkdir,"/bin/mkdir",NULL,NULL,chCommandWithAttr,NULL);
    ui->tfMkdirPid->setText(QString::number(iPIDMkdir));


}

void HomeScreen::on_bShoePwd_clicked()
{
    //Required Variables
    int iPIDPWD,iStatusPWD;
    char chCommand[] = "pwd";

    char* chCommandWithAttr[] = {chCommand,0};

    iStatusPWD = posix_spawnp(&iPIDPWD,"/bin/pwd",NULL,NULL,chCommandWithAttr,NULL);
    ui->tfPIDPWD->setText(QString::number(iPIDPWD));
}
